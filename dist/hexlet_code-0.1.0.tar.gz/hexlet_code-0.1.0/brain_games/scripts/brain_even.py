#!/usr/bin/env Python3

from brain_games import even_game

def main():
    print('Welcome to the Brain Games!\n')
    even_game.even_game()


if __name__ == '__main__':
    main()
