### Hexlet tests and linter status:
[![Actions Status](https://github.com/preveed/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/preveed/python-project-49/actions)
### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/0a484eecba4799c3962f/maintainability)](https://codeclimate.com/github/preveed/python-project-49/maintainability)
