#!/usr/bin/env Python3

from brain_games import cli

def main():
	print('Welcome to the Brain Games!\n')
	cli.welcome_user()

if __name__ == '__main__':
	main()
